import os
import pickle
import sys
import time
import urllib.request
import urllib.error
from ecc_utils import Point, pollard_rho, multiply_point
from bac import count_points
from cryptography.fernet import Fernet
import base64

def decode_message(C1, C2, x, p):
    xC1 = multiply_point(C1, x)
    neg_xC1 = Point(xC1.x, (-xC1.y) % p, xC1.a, xC1.b, xC1.p)
    M = C2 + neg_xC1
    return M

def decrypt_content(m, encrypted_content):
    key = base64.urlsafe_b64encode(str(m).zfill(32).encode())
    fernet = Fernet(key)
    try:
        decrypted_content = fernet.decrypt(encrypted_content).decode()
        return decrypted_content
    except Exception as e:
        raise ValueError(f"Failed to decrypt content: {e}")

def download_file():
    url = "http://192.15.2.4:8000/thongdiepmahoa.pkl"
    local_path = "/home/ubuntu/shared/thongdiepmahoa.pkl"
    timeout = 30
    start_time = time.time()
    try:
        os.makedirs("/home/ubuntu/shared", exist_ok=True)
    except Exception as e:
        print(f"Attack: Failed to create shared directory: {e}")
        sys.exit(1)
    while True:
        try:
            urllib.request.urlretrieve(url, local_path)
            break
        except urllib.error.URLError as e:
            print(f"Attack: URLError: {e}")
            if time.time() - start_time > timeout:
                print(f"Attack: Failed to download file after {timeout} seconds: {e}")
                sys.exit(1)
            print(f"Attack: Waiting for server to be ready... ({e})")
            time.sleep(2)

if __name__ == "__main__":
    download_file()
    print("Harry: Đọc thông điệp mã hoá...")
    try:
        with open("shared/thongdiepmahoa.pkl", "rb") as f:
            C1, C2, encrypted_content, P, Q, a, b, p = pickle.load(f)
        print(f"Harry: Tìm ra C1 = {C1}, C2 = {C2}, a = {a}, b = {b}, p = {p}, P = {P}, Q = {Q}")
    except Exception as e:
        print(f"Harry: Failed to read thongdiepmahoa.pkl: {e}")
        sys.exit(1)

    print("Harry: Chạy Pollard-Rho attack...")
    try:
        n = count_points(a, b, p)
        x_found = pollard_rho(P, Q, n)
        print(f"Harry: Tìm ra khoá bí mật của alice là: {x_found}")
        M = decode_message(C1, C2, x_found, p)
        print(f"Harry: Giải mã được M: {M}")
        m_hacked = M.x
        content = decrypt_content(m_hacked, encrypted_content)
        print(f"Harry: Decrypted content: {content}")
    except Exception as e:
        print(f"Harry: Attack failed: {e}")
