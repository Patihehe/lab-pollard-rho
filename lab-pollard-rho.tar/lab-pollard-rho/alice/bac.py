def is_quadratic_residue(n, p):
    return pow(n, (p-1)//2, p) == 1

def count_points(a, b, p):
    N = 1  # Điểm vô cực
    for x in range(p):
        y_squared = (x**3 + a*x + b) % p
        if y_squared == 0:
            N += 1
        elif is_quadratic_residue(y_squared, p):
            N += 2
    return N
