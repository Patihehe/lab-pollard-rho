class Point:
    def __init__(self, x, y, a, b, p):
        self.a = a % p
        self.b = b % p
        self.p = p
        self.x = x % p if x is not None else None
        self.y = y % p if y is not None else None
        if x is not None and y is not None:
            if (y * y - (x * x * x + a * x + b)) % p != 0:
                raise ValueError(f"Point ({x}, {y}) does not lie on curve y^2 = x^3 + {a}x + {b} mod {p}")

    def __repr__(self):
        if self.x is None:
            return "O"
        return f"({self.x}, {self.y})"

    def __eq__(self, other):
        if self.x is None and other.x is None:
            return True
        if self.x is None or other.x is None:
            return False
        return self.x == other.x and self.y == other.y and self.p == other.p

    def __add__(self, other):
        if self.p != other.p:
            raise ValueError("Points are on different fields")
        if self.x is None:
            return other
        if other.x is None:
            return self
        if self.x == other.x and (self.y + other.y) % self.p == 0:
            return Point(None, None, self.a, self.b, self.p)
        if self.x == other.x:
            if self.y == 0:
                return Point(None, None, self.a, self.b, self.p)
            m = (3 * self.x**2 + self.a) * pow(2 * self.y, -1, self.p) % self.p
        else:
            m = (other.y - self.y) * pow(other.x - self.x, -1, self.p) % self.p
        x3 = (m**2 - self.x - other.x) % self.p
        y3 = (m * (self.x - x3) - self.y) % self.p
        return Point(x3, y3, self.a, self.b, self.p)

    def double(self):
        return self + self

class RhoPoint:
    def __init__(self, point, a_coeff, b_coeff, n):
        self.point = point
        self.a = a_coeff % n
        self.b = b_coeff % n
        self.n = n

    def __repr__(self):
        return f"R: {self.point}, a: {self.a}, b: {self.b}"

    def apply_f(self, P, Q):
        if self.point.x is None:
            part = 1
        else:
            y = self.point.y
            p = self.point.p
            third = p // 3
            if 0 <= y < third:
                part = 1
            elif third <= y < 2 * third:
                part = 2
            else:
                part = 3
        if part == 1:
            new_point = self.point + Q
            new_a = self.a
            new_b = (self.b + 1) % self.n
        elif part == 2:
            new_point = self.point.double()
            new_a = (2 * self.a) % self.n
            new_b = (2 * self.b) % self.n
        elif part == 3:
            new_point = self.point + P
            new_a = (self.a + 1) % self.n
            new_b = self.b
        return RhoPoint(new_point, new_a, new_b, self.n)

def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        t = m
        m = a % m
        a = t
        t = x0
        x0 = x1 - q * x0
        x1 = t
    if x1 < 0:
        x1 += m0
    return x1 % m0

def pollard_rho(P, Q, n):
    if P.p != Q.p:
        raise ValueError("Points P and Q must be in the same field")
    R0 = RhoPoint(P, 1, 0, n)
    tortoise = R0
    hare = R0
    i = 0
    while True:
        i += 1
        tortoise = tortoise.apply_f(P, Q)
        hare = hare.apply_f(P, Q).apply_f(P, Q)
        if tortoise.point == hare.point:
            break
    num = (tortoise.a - hare.a) % n
    den = (hare.b - tortoise.b) % n
    if den == 0:
        raise ValueError("Denominator is zero; try different initial point or partitioning")
    inv_den = mod_inverse(den, n)
    x = (num * inv_den) % n
    return x

def multiply_point(P, k):
    result = Point(None, None, P.a, P.b, P.p)
    addend = P
    while k > 0:
        if k & 1:
            result = result + addend
        addend = addend.double()
        k >>= 1
    return result
