import os
import pickle
import threading
import http.server
import socketserver
from ecc_utils import Point, multiply_point
from cryptography.fernet import Fernet
import base64
from bac import count_points


def is_quadratic_residue(n, p):
    return pow(n, (p - 1) // 2, p) == 1


def map_to_point(m, a, b, p):
    x_m = m % p
    y_squared = (x_m ** 3 + a * x_m + b) % p
    if is_quadratic_residue(y_squared, p):
        y_m = pow(y_squared, (p + 1) // 4, p)
        return Point(x_m, y_m, a, b, p)
    raise ValueError(f"Cannot map m={m} to a point on the curve")


def find_valid_m(a, b, p):
    for m in range(p):
        try:
            point = map_to_point(m, a, b, p)
            return m, point
        except ValueError:
            continue
    raise ValueError(f"No valid m found for curve y^2 = x^3 + {a}x + {b} mod {p}. Try different a, b, p.")


def encode_message(content, P, Q, p):
    m, M = find_valid_m(a, b, p)
    k = 5  # Số ngẫu nhiên
    C1 = multiply_point(P, k)
    C2 = M + multiply_point(Q, k)
    key = base64.urlsafe_b64encode(str(m).zfill(32).encode())
    fernet = Fernet(key)
    encrypted_content = fernet.encrypt(content.encode())
    return C1, C2, encrypted_content


def save_message(C1, C2, encrypted_content):
    os.makedirs("/home/ubuntu/shared", exist_ok=True)  # Dùng thư mục trong home
    with open("/home/ubuntu/shared/thongdiepmahoa.pkl", "wb") as f:
        pickle.dump((C1, C2, encrypted_content, P, Q, a, b, p), f)
    print("Alice: Encrypted message saved to /home/ubuntu/shared/thongdiepmahoa.pkl")


class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/thongdiepmahoa.pkl":
            super().do_GET()
            self.server.shutdown()
            os._exit(0)
        else:
            super().do_GET()


def start_server():
    os.makedirs("/home/ubuntu/shared", exist_ok=True)
    os.chdir("/home/ubuntu/shared")
    PORT = 8000
    Handler = CustomHandler
    httpd = socketserver.TCPServer(("", PORT), Handler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.server_close()
    finally:
        os._exit(0)


if __name__ == "__main__":
    try:
        print("Nhập các tham số của đường cong:")
        print("Nhập a, b, p:")
        a, b, p = map(int, input().split())
        print("Nhập toạ độ điểm sinh P: ")
        x1, y1 = map(int, input().split())
        P = Point(x1, y1, a, b, p)
    except ValueError as e:
        print(f"Error: Invalid input or point not on curve: {e}")
        exit(1)

    try:
        print("Nhập khoá bí mật để mã hoá: ")
        x = int(input())
        Q = multiply_point(P, x)
    except ValueError as e:
        print(f"Error: Invalid secret key x: {e}")
        exit(1)

    try:
        n = count_points(a, b, p)
        if n <= 2:
            print("Error: Curve has too few points to find a valid m. Try different a, b, p.")
            exit(1)
    except Exception as e:
        print(f"Error counting points: {e}")
        exit(1)

    content = input("Alice: Nhập nội dung cần mã hóa: ")
    print("Alice: Mã hoá thông điệp...")
    try:
        C1, C2, encrypted_content = encode_message(content, P, Q, p)
        print(f"Alice: Encoded message: C1 = {C1}, C2 = {C2}")
        save_message(C1, C2, encrypted_content)
    except ValueError as e:
        print(f"Error: {e}")
        exit(1)

    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()
    print("...")
    try:
        server_thread.join(timeout=30)  # Đợi tối đa 30 giây
        if server_thread.is_alive():
            os._exit(0)
    except KeyboardInterrupt:
        os._exit(0)
