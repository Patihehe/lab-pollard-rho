import pickle
import sys
from ecc_utils import Point, multiply_point, mod_inverse
from bac import count_points
import base64
import hashlib
from math import gcd, sqrt, ceil
import urllib.request
import time

#reasive data
def download_file():
    url = "http://192.10.1.17:8000/encrypted_message.pkl"
    local_path = "/shared/encrypted_message.pkl"
    print("Attack: Downloading encrypted_message.pkl...")
    timeout = 30  # Đợi tối đa 30 giây
    start_time = time.time()
    while True:
        try:
            urllib.request.urlretrieve(url, local_path)
            print("Attack: Download complete!")
            break
        except urllib.error.URLError as e:
            if time.time() - start_time > timeout:
                print(f"Attack: Failed to download file after {timeout} seconds: {e}")
                sys.exit(1)
            print(f"Attack: Waiting for server to be ready... ({e})")
            time.sleep(2)  # T


def simple_encrypt(data, key):
    """Mã hóa đơn giản sử dụng XOR với key được mở rộng"""
    key_bytes = hashlib.sha256(str(key).encode()).digest()
    encrypted = bytearray()

    for i, byte in enumerate(data):
        encrypted.append(byte ^ key_bytes[i % len(key_bytes)])

    return bytes(encrypted)


def simple_decrypt(encrypted_data, key):
    """Giải mã đơn giản (XOR là symmetric)"""
    return simple_encrypt(encrypted_data, key)


def extended_gcd(a, b):
    """Extended Euclidean Algorithm"""
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = extended_gcd(b % a, a)
        return (g, x - (b // a) * y, y)


def point_to_string(point):
    """Chuyển điểm thành string để làm key cho dictionary"""
    if point.x is None:
        return "O"
    return f"{point.x},{point.y}"


def multiply_point_safe(P, k):
    """Nhân điểm an toàn, xử lý cả số âm"""
    if k == 0:
        return Point(None, None, P.a, P.b, P.p)

    if k < 0:
        # Tính -kP = k(-P)
        neg_P = Point(P.x, (-P.y) % P.p if P.x is not None else None, P.a, P.b, P.p)
        return multiply_point(neg_P, -k)
    else:
        return multiply_point(P, k)


def baby_step_giant_step(P, Q, order, verbose=False):
    """Giải bài toán logarithm rời rạc sử dụng Baby-step Giant-step"""
    if P.x is None or Q.x is None:
        if P.x is None and Q.x is None:
            return 0
        return None

    m = int(ceil(sqrt(order))) + 1
    if verbose:
        print(f"    BSGS: m = {m}, order = {order}")

    # Baby steps: lưu jP cho j = 0, 1, ..., m-1
    baby_steps = {}
    current = Point(None, None, P.a, P.b, P.p)  # Điểm vô cực (0P)

    for j in range(m):
        key = point_to_string(current)
        if key not in baby_steps:
            baby_steps[key] = j
        current = current + P

    # Giant steps: tính -mP
    mP = multiply_point(P, m)
    neg_mP = Point(mP.x, (-mP.y) % P.p if mP.x is not None else None, P.a, P.b, P.p)

    # Tìm Q - imP trong baby_steps
    current = Q
    for i in range(m):
        key = point_to_string(current)
        if key in baby_steps:
            j = baby_steps[key]
            result = i * m + j
            if verbose:
                print(f"    BSGS: Found collision at i={i}, j={j}, result={result}")

            # Kiểm tra kết quả
            if 0 <= result < order:
                test_point = multiply_point(P, result)
                if test_point == Q:
                    return result

        current = current + neg_mP

    return None


def pohlig_hellman(P, Q, order_factors, p, verbose=False):
    """Giải bài toán DLP sử dụng thuật toán Pohlig-Hellman"""
    order = 1
    for p_factor, e in order_factors:
        order *= p_factor ** e

    if verbose:
        print(f"Harry: Total order = {order}")

    congruences = []
    moduli = []

    for p_factor, e in order_factors:
        if verbose:
            print(f"\nHarry: Processing factor {p_factor}^{e}")

        pe = p_factor ** e

        # Tính P' = (n/p^e)P và Q' = (n/p^e)Q
        cofactor = order // pe
        P_sub = multiply_point(P, cofactor)
        Q_sub = multiply_point(Q, cofactor)

        if verbose:
            print(f"Harry: Cofactor = {cofactor}")
            print(f"Harry: P_sub = {P_sub}, Q_sub = {Q_sub}")

        # Nếu cả P_sub và Q_sub đều là điểm vô cực
        if P_sub.x is None and Q_sub.x is None:
            congruences.append(0)
            moduli.append(pe)
            if verbose:
                print(f"Harry: Both points are identity, x ≡ 0 (mod {pe})")
            continue

        # Nếu P_sub là điểm vô cực nhưng Q_sub không
        if P_sub.x is None and Q_sub.x is not None:
            if verbose:
                print(f"Harry: P_sub is identity but Q_sub is not - no solution")
            raise ValueError(f"No solution in subgroup of order {pe}")

        # Giải DLP trong nhóm con cấp pe
        if e == 1:
            # Trường hợp đơn giản: nhóm con cấp nguyên tố
            x = baby_step_giant_step(P_sub, Q_sub, p_factor, verbose)
            if x is None:
                raise ValueError(f"Cannot solve DLP in subgroup of order {p_factor}")
        else:
            # Trường hợp tổng quát: sử dụng Pohlig-Hellman đệ quy
            x = 0
            gamma = Q_sub

            for j in range(e):
                # Tính P_j = p^(e-1-j) * P_sub
                exp = p_factor ** (e - 1 - j)
                P_j = multiply_point(P_sub, exp)
                gamma_j = multiply_point(gamma, exp)

                if verbose:
                    print(f"  Step {j}: P_j = {P_j}, gamma_j = {gamma_j}")

                # Giải DLP: gamma_j = d_j * P_j
                d_j = baby_step_giant_step(P_j, gamma_j, p_factor, verbose)
                if d_j is None:
                    if verbose:
                        print(f"  Cannot solve DLP at step {j}")
                    raise ValueError(f"Cannot solve DLP in subgroup of order {p_factor}")

                # Cập nhật x và gamma
                x += d_j * (p_factor ** j)
                correction = multiply_point_safe(P_sub, d_j * (p_factor ** j))
                # gamma := gamma - d_j * p^j * P_sub
                neg_correction = Point(correction.x, (-correction.y) % p if correction.x is not None else None,
                                       correction.a, correction.b, correction.p)
                gamma = gamma + neg_correction

                if verbose:
                    print(f"  d_{j} = {d_j}, partial x = {x}")

        congruences.append(x % pe)
        moduli.append(pe)
        if verbose:
            print(f"Harry: x ≡ {x % pe} (mod {pe})")

    # Sử dụng Chinese Remainder Theorem
    result = crt(congruences, moduli)
    if verbose:
        print(f"Harry: CRT result: {result}")
    return result


def crt(a_list, m_list):
    """Chinese Remainder Theorem"""
    if len(a_list) != len(m_list):
        return None

    M = 1
    for m in m_list:
        M *= m

    x = 0
    for a, m in zip(a_list, m_list):
        Mi = M // m
        try:
            inv = mod_inverse(Mi, m)
            x += a * Mi * inv
            x %= M
        except ValueError:
            return None

    return x


def get_prime_factors(n):
    """Tìm các thừa số nguyên tố của n"""
    factors = []
    d = 2
    while d * d <= n:
        count = 0
        while n % d == 0:
            n //= d
            count += 1
        if count > 0:
            factors.append((d, count))
        d += 1
    if n > 1:
        factors.append((n, 1))
    return factors


def decode_message(C1, C2, x, p):
    """Giải mã tin nhắn ElGamal"""
    # Tính xC1
    xC1 = multiply_point(C1, x)
    # Tính M = C2 - xC1 = C2 + (-xC1)
    neg_xC1 = Point(xC1.x, (-xC1.y) % p, xC1.a, xC1.b, xC1.p) if xC1.x is not None else xC1
    M = C2 + neg_xC1
    return M


def decrypt_content(m, encrypted_content_b64):
    """Giải mã nội dung sử dụng simple decryption"""
    try:
        # Decode from base64
        encrypted_content = base64.b64decode(encrypted_content_b64)
        # Decrypt using simple XOR
        decrypted_bytes = simple_decrypt(encrypted_content, m)
        decrypted_content = decrypted_bytes.decode('utf-8')
        return decrypted_content
    except Exception as e:
        raise ValueError(f"Failed to decrypt content: {e}")


def brute_force_attack(P, Q, p, max_attempts=None):
    """Tấn công brute force để tìm khóa bí mật"""
    if max_attempts is None:
        max_attempts = p

    print(f"Harry: Trying brute force attack (max {max_attempts} attempts)...")
    for x in range(1, min(max_attempts + 1, p)):
        test_Q = multiply_point(P, x)
        if test_Q == Q:
            return x
    return None


if __name__ == "__main__":
    print("Harry's Attack on ElGamal ECC")
    print("=" * 40)
    download_file()

    # print("Attack: Waiting for encrypted message...")
    # download_file()
    # Đọc tin nhắn đã mã hóa
    print("Harry: Reading encrypted message...")
    try:
        with open("/shared/encrypted_message.pkl", "rb") as f:
            data = pickle.load(f)

        if isinstance(data, dict):
            C1 = data['C1']
            C2 = data['C2']
            encrypted_content = data['encrypted_content']
            P = data['P']
            Q = data['Q']
            a, b, p = data['curve_params']
            m_original = data['m']
        else:
            # Backward compatibility
            C1, C2, encrypted_content, P, Q, a, b, p, m_original = data

        print(f"Harry: Successfully loaded encrypted message")
        print(f"Harry: C1 = {C1}")
        print(f"Harry: C2 = {C2}")
        print(f"Harry: Original m = {m_original}")

    except Exception as e:
        print(f"Harry: Failed to read encrypted_message.pkl: {e}")
        sys.exit(1)

    # Tấn công Pohlig-Hellman
    print("\nHarry: Starting Pohlig-Hellman attack...")
    try:
        # Đếm số điểm trên đường cong
        n = count_points(a, b, p)
        print(f"Harry: Order of the elliptic curve group: {n}")

        # Phân tích thừa số nguyên tố
        factors = get_prime_factors(n)
        print(f"Harry: Prime factorization: {n} = ", end="")
        factor_strs = [f"{p}^{e}" if e > 1 else str(p) for p, e in factors]
        print(" × ".join(factor_strs))

        # Kiểm tra xem có thể tấn công Pohlig-Hellman không
        largest_factor = max(factors, key=lambda x: x[0] ** x[1])
        if largest_factor[0] ** largest_factor[1] > 1000:
            print(
                f"Harry: Largest prime factor {largest_factor[0]}^{largest_factor[1]} is too large for Pohlig-Hellman")
            raise ValueError("Prime factors too large")

        # Chạy Pohlig-Hellman
        x_found = pohlig_hellman(P, Q, factors, p, verbose=True)
        print(f"\nHarry: Found secret key x = {x_found}")

        # Xác minh khóa bí mật
        verify_Q = multiply_point(P, x_found)
        if verify_Q == Q:
            print("Harry: Secret key verification successful!")
        else:
            print(f"Harry: Warning! Secret key verification failed.")
            print(f"Harry: Computed Q = {verify_Q}, Expected Q = {Q}")
            raise ValueError("Secret key verification failed")

        # Giải mã tin nhắn
        M = decode_message(C1, C2, x_found, p)
        print(f"Harry: Decoded point M = {M}")

        # Giải mã nội dung
        m_decoded = M.x if M.x is not None else 0
        content = decrypt_content(m_decoded, encrypted_content)
        print(f"Harry: Decrypted content: '{content}'")

        # Xác minh kết quả
        if m_decoded == m_original:
            print(f"Harry: Perfect! Decoded m ({m_decoded}) matches original m ({m_original})")
        else:
            print(f"Harry: Warning! Decoded m ({m_decoded}) != original m ({m_original})")

        print("\nHarry: Pohlig-Hellman attack completed successfully!")

    except Exception as e:
        print(f"Harry: Pohlig-Hellman attack failed: {e}")

        # Fallback to brute force
        print("\nHarry: Falling back to brute force attack...")
        x_found = brute_force_attack(P, Q, p, max_attempts=100)

        if x_found is not None:
            print(f"Harry: Found secret key x = {x_found} using brute force")

            # Giải mã tin nhắn
            M = decode_message(C1, C2, x_found, p)
            print(f"Harry: Decoded point M = {M}")

            m_decoded = M.x if M.x is not None else 0
            content = decrypt_content(m_decoded, encrypted_content)
            print(f"Harry: Decrypted content: '{content}'")

            print("Harry: Brute force attack successful!")
        else:
            print("Harry: All attacks failed!")
            sys.exit(1)
