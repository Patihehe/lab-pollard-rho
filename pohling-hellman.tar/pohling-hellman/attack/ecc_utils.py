class Point:
    def __init__(self, x, y, a, b, p):
        self.a = a % p
        self.b = b % p
        self.p = p
        self.x = x % p if x is not None else None
        self.y = y % p if y is not None else None
        if x is not None and y is not None:
            if (y * y - (x * x * x + a * x + b)) % p != 0:
                raise ValueError(f"Point ({x}, {y}) does not lie on curve y^2 = x^3 + {a}x + {b} mod {p}")

    def __repr__(self):
        if self.x is None:
            return "O"
        return f"({self.x}, {self.y})"

    def __eq__(self, other):
        if not isinstance(other, Point):
            return False
        if self.x is None and other.x is None:
            return True
        if self.x is None or other.x is None:
            return False
        return self.x == other.x and self.y == other.y and self.p == other.p

    def __add__(self, other):
        if self.p != other.p:
            raise ValueError("Points are on different fields")
        if self.x is None:
            return other
        if other.x is None:
            return self
        if self.x == other.x and (self.y + other.y) % self.p == 0:
            return Point(None, None, self.a, self.b, self.p)
        if self.x == other.x:
            if self.y == 0:
                return Point(None, None, self.a, self.b, self.p)
            m = (3 * self.x ** 2 + self.a) * pow(2 * self.y, -1, self.p) % self.p
        else:
            m = (other.y - self.y) * pow(other.x - self.x, -1, self.p) % self.p
        x3 = (m ** 2 - self.x - other.x) % self.p
        y3 = (m * (self.x - x3) - self.y) % self.p
        return Point(x3, y3, self.a, self.b, self.p)

    def double(self):
        return self + self

    def negate(self):
        """Trả về điểm đối của điểm hiện tại"""
        if self.x is None:
            return Point(None, None, self.a, self.b, self.p)
        return Point(self.x, (-self.y) % self.p, self.a, self.b, self.p)


def mod_inverse(a, m):
    """Tính nghịch đảo modular của a mod m"""

    def extended_gcd(a, b):
        if a == 0:
            return b, 0, 1
        gcd, x1, y1 = extended_gcd(b % a, a)
        x = y1 - (b // a) * x1
        y = x1
        return gcd, x, y

    gcd, x, _ = extended_gcd(a % m, m)
    if gcd != 1:
        raise ValueError(f"Modular inverse of {a} mod {m} does not exist")
    return (x % m + m) % m


def multiply_point(P, k):
    """Nhân điểm P với số nguyên k (có thể âm)"""
    if k == 0:
        return Point(None, None, P.a, P.b, P.p)

    if k < 0:
        # Tính -kP = k(-P)
        neg_P = P.negate()
        return multiply_point_positive(neg_P, -k)
    else:
        return multiply_point_positive(P, k)


def multiply_point_positive(P, k):
    """Nhân điểm P với số nguyên dương k sử dụng binary method"""
    if k == 0:
        return Point(None, None, P.a, P.b, P.p)
    if k == 1:
        return P

    result = Point(None, None, P.a, P.b, P.p)  # Điểm vô cực
    addend = P

    while k > 0:
        if k & 1:  # Nếu bit thấp nhất là 1
            result = result + addend
        addend = addend.double()
        k >>= 1  # Dịch phải 1 bit

    return result
