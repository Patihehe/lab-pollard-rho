def is_quadratic_residue(n, p):
    """Kiểm tra xem n có phải là quadratic residue mod p không"""
    if n == 0:
        return True
    return pow(n, (p-1)//2, p) == 1

def count_points(a, b, p):
    """Đếm số điểm trên đường cong elliptic y^2 = x^3 + ax + b mod p"""
    N = 1  # Điểm vô cực O
    for x in range(p):
        y_squared = (x**3 + a*x + b) % p
        if y_squared == 0:
            N += 1  # Chỉ có một điểm (x, 0)
        elif is_quadratic_residue(y_squared, p):
            N += 2  # Có hai điểm (x, y) và (x, -y)
    return N

def sqrt_mod_p(n, p):
    """Tính căn bậc hai modular của n mod p (với p ≡ 3 mod 4)"""
    if not is_quadratic_residue(n, p):
        return None
    if p % 4 == 3:
        return pow(n, (p + 1) // 4, p)
    else:
        # Implement Tonelli-Shanks algorithm for general case
        # For simplicity, we'll only handle p ≡ 3 mod 4
        raise NotImplementedError("Only supports primes p ≡ 3 mod 4")
